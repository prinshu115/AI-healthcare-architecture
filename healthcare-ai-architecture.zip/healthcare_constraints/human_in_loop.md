## Human-in-the-Loop

AI output is never treated as final clinical advice.

Human checkpoints are mandatory when:
- Clinical recommendations are generated
- Coding or documentation impacts billing
- Ambiguity exceeds a defined threshold

Automation stops where accountability begins.